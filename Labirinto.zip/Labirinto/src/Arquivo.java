import java.io.*;

public class Arquivo {
    private String caminhoArquivoEntrada = System.getProperty("user.home") + "/IdeaProjects/Labirinto/src/";
    private String caminhoArquivoSaida = System.getProperty("user.home") + "/IdeaProjects/Labirinto/src/";
    private BufferedReader arquivoEntrada;
    private BufferedWriter arquivoSaida;

    private String nomeDoArquivo;
    private Integer numLinhas;
    private Integer numColunas;

    public Arquivo(String nome){
        BufferedReader in = null;
        BufferedWriter out = null;

        try
        {
            caminhoArquivoEntrada = caminhoArquivoEntrada + nome + "1.txt";
            caminhoArquivoSaida = caminhoArquivoSaida + nome + "2.txt";
            in = new BufferedReader(new FileReader(caminhoArquivoEntrada));
            out = new BufferedWriter(new FileWriter(caminhoArquivoSaida ));

            String str;
            while ((str = in.readLine()) != null){
                out.write(str+"\n");
                //System.out.println(str);
            }
            this.arquivoEntrada = in;
            this.arquivoSaida = out;
        }
        catch (IOException erro){
            System.out.println(erro);
        }
    }//

    public void preencherMatriz(char [][] mat){

        String ret = "";

        for (int i = 0 ; i < mat.length ; i++) {
            for (int j = 0 ; j < mat[i].length; j++) {
                //mat[j][i];
            }
            ret += "\n";
        }
    }


    public String toString (){
        String ret = "";
        try
        {
            this.arquivoEntrada = new BufferedReader(new FileReader(caminhoArquivoEntrada));

            String str;
            while ((str = this.arquivoEntrada.readLine()) != null){
                ret += str + "\n";
                //System.out.println(str);
            }
        }
        catch (IOException erro){
        }
        return ret;
    }
}

/*
    public Arquivo(String nome){
        try{
            arquivo = new BufferedReader(new FileReader(nome).readAsText());
        }
        catch (IOException erro){
            System.err.println("Arquivo invalido.");
        }
    }*/
