import java.io.*;
import java.nio.file.FileSystems;
import java.util.Objects;

public class Arquivo {
    private BufferedReader arquivoReader;
    private String caminhoDeEntrada;

    public Arquivo(String nomeDoArquivo) throws Exception {
        if (nomeDoArquivo == "" || nomeDoArquivo == null)
            throw new Exception("Nome do arquivo nulo");

        try
        {
            // MACOS working:
            // this.caminhoDeEntrada =  System.getProperty("user.home") + "/IdeaProjects/Labirinto/src/Testes/" + nomeDoArquivo;
            this.caminhoDeEntrada =  FileSystems.getDefault().getPath("src/Testes/" + nomeDoArquivo).toAbsolutePath().toString();

            this.arquivoReader = new BufferedReader(new FileReader(this.caminhoDeEntrada));
        }
        catch (IOException erro){
            throw new Exception("Arquivo nao encontrado");
        }
    }

    public String pegaProximaLinha(){
        String ret = null;

        try
        {
            ret = arquivoReader.readLine();
        }
        catch (IOException erro)
        {}

        return ret;
    }

    public int pegaUmInt() throws Exception {
        int ret = 0;

        try
        {
            ret = Integer.parseInt(arquivoReader.readLine());
        }
        catch (IOException erro)
        {} // sei que nao vai dar erro
        catch (NumberFormatException erro)
        {
            throw new Exception ("Int invalido!");
        }

        return ret;
    }

    public void fecharArquivo() throws Exception {
        arquivoReader.close();
    }

    public void lerNovamente() throws Exception {
        try
        {
            this.arquivoReader = new BufferedReader(new FileReader(this.caminhoDeEntrada));
        }
        catch (IOException erro){
            throw new Exception(erro);
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;

        if (this.getClass() != obj.getClass()) return false;

        Arquivo arq = (Arquivo) obj;

        if (!this.arquivoReader.equals(arq.arquivoReader))
            return false;

        if (!this.caminhoDeEntrada.equals(arq.caminhoDeEntrada))
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int ret = 666;

        ret = 7* ret + this.caminhoDeEntrada.hashCode();
        ret = 7* ret + this.arquivoReader.hashCode();

        if (ret < 0) ret = -ret;

        return ret;
    }
}
