public class Main {
    public static void main(String[] args) throws Exception {
        Fila<Integer> p = new Fila<Integer>(10);
        //Teclado teclado = new Teclado();

        Arquivo arquivo = new Arquivo("teste");

        Pilha<Coordenada> pilhaCoordenada = new Pilha<Coordenada>(10);
        Coordenada coordenada = new Coordenada(3,2);

        System.out.println(arquivo);

    }
}
