public class Matriz <X> implements Cloneable {
    private char [][] matriz ;
    private int numColunas;
    private int numLinhas;

    public Matriz (int numLinhas, int numColunas) {
        this.matriz = new char[numLinhas][numColunas];
        this.numColunas = numColunas;
        this.numLinhas = numLinhas;
    }

    public Matriz () {
        this.matriz = new char[5][8];
        this.numColunas = 8;
        this.numLinhas = 5;
    }

    public void preencherMatriz(String str){

    }
    public void preencherPosicao(String, int posicaoLinha, int posicaoColuna){
        if (x==null)
            throw new Exception ("Falta preencher colunas e linhas");

        if (this.ultimo+1==this.elemento.length) // cheia
            this.redimensioneSe (2.0F);

        this.ultimo++;

        if (x instanceof Cloneable)
            this.elemento[][] = meuCloneDeX(x);
        else
        this.elemento[this.ultimo][] =x;
    }

    @Override
    public String toString() {
        String ret = "";

        for (int i = 0; i < this.matriz.length; i++){
            for (int j = 0; j < this.matriz[i].length; j++){
                ret += this.matriz[j][i];
            }
            ret += "\n";
        }
        return ret;
    }


    public boolean equals (Object obj) {
        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (this.getClass() != obj.getClass())
            return false;

        Matriz<X> pil = (Matriz<X>) obj;
        return true;
    }

    public Object clone ()
    {
        Matriz<X> ret=null;

        try
        {
            //ret = new Matriz<X>(this);
        }
        catch(Exception erro)
        {}

        return ret;
    }
    private void redimensioneSe (float fator)
    {
        // X[] novo = new X [Math.round(this.elemento.length*fator)];
        Object[] novo = new Object [Math.round(this.elemento.length*fator)];

        for(int i=0; i<=this.ultimo; i++)
            novo[i] = this.elemento[i];

        this.elemento = novo;
    }
}



