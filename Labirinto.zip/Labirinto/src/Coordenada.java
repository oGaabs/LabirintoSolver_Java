public class Coordenada {
    private int x;
    private int y;

    public Coordenada (int x, int y){
        this.x = x;
        this.y = y;
    }
        //caminho = new Caminho(){}


    @Override
    public String toString() {

        String ret = (this.x) + " " + (this.y);
        return ret;
    }
}
